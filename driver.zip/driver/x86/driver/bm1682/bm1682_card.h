#ifndef _BM1682_CARD_H_
#define _BM1682_CARD_H_

void bm1682_stop_arm9(struct bm_device_info *bmdi);
void bm1682_start_arm9(struct bm_device_info *bmdi);
void bm1682_top_init(struct bm_device_info *bmdi);
#endif
