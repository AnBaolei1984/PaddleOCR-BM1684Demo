#ifndef _BM1684_SMBUS_H_
#define _BM1684_SMBUS_H_
#ifndef SOC_MODE

void bmdrv_smbus_set_default_value(struct pci_dev *pdev, struct bm_device_info *bmdi);

#endif
#endif
